=== Google Analytics and Mixpanel by WordPressview ===
Contributors: WordPressview
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=3T9VTUHGRB8BL
Tags: analytics, google analytics, statistics, tracking, stats, google, mixpanel
Requires at least: 3.8
Tested up to: 4.2
Stable tag: trunk
License: GPL v3

Track your WordPress site easily with the latest tracking codes With Google Analytics or Mixpanel.

== Description ==

The Google Analytics and Mixpanel by WordPressview plugin for WordPress allows you to track your blog easily and always stays up to date with the newest features in Google Analytics and Mixpanel.


Full list of features:

* Simple installation through integration with Google Analytics API: authenticate, select the site you want to track and you're done.
* Simple installation through integration with Mixpanel API: authenticate, select the site you want to track and you're done.
* This plugin uses  Google Analytics tracking code, the fastest and most reliable tracking code Google Analytics offers.
* Option to enable demographics and interest reports.
* downloads tracking.
* Option to track just downloads as pageviews or events in Google Analytics or in Mixpanel.
* Tracking of your search result pages and 404 pages.

== Installation ==

This section describes how to install the plugin and get it working.

1. Upload `google-analytics-mixpanel-for-wordpress` folder to the `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress
1. Go to the options panel under the 'Wordpressview' menu and add your Google Analytics account number or Mixpanel token.

== Changelog ==

= 5.4.4 =

Release Date: July 17th, 2015

* first version!

== Frequently Asked Questions ==

= How fast can I connect my wordpress sire to Google analytics or Mixpanel with this plguin =

real fast! follow this 4 steps and your connection is ready:

* Install the WordPressview plugin

* Activate the WordPressview plugin

* Go to the WordPressview settings, add a Google Analytics tracking ID or Mixpanel token.

* Press "Save changes".

That's it, your WordPress site is being tracked by Google Analytics or Mixpanel ;-)

= Where can I find the settings to adjust the WordPressview plugin work after activation? =

In the WordPress dashboard menu you can find the "WordPressview" menu to the settings page.

== Screenshots ==

1. Screenshot of the dashboards menu
2. Screenshot of the general settings panel for this plugin.
